<?php
/**
 * Central Database Connection
 * Used by: API, Admin Panel, Geo, Helpers
 */

declare(strict_types=1);

// ---- ENV / CONFIG ----
$host = "localhost";
$db   = "newsxpre1_news_app_api";     // EXACT database name
$user = "newsxpre1_news_app_api";     // DB username
$pass = "@News_app123";    // DB password
$charset = "utf8mb4";

// ---- DSN ----
$dsn = "mysql:host={$host};dbname={$db};charset={$charset}";

// ---- PDO OPTIONS ----
$options = [
    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    PDO::ATTR_EMULATE_PREPARES   => false,
];

try {
    $pdo = new PDO($dsn, $user, $pass, $options);
} catch (PDOException $e) {
    // ⚠️ Do NOT expose DB details in production
    error_log('DB Connection Error: ' . $e->getMessage());
    http_response_code(500);
    die('Database connection error');
}
